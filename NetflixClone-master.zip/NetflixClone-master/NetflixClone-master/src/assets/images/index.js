import Weird from './weird.png'
import Profile from './profile.jpg'
import Smile from './smile.png'
import Normal from './normal.jpg'
import NetflixLogo from './netflix.png'
import LoginBackground from './landingPage.jpg'

export {
    Weird, 
    Profile, 
    Smile, 
    Normal,
    NetflixLogo, 
    LoginBackground
} 