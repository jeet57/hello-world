import React from 'react'
import './LoadingScreen.css'

const loadingScreen = props => {
    return (
        <div className="LoadingScreen">
        </div>
    )
}

export default loadingScreen