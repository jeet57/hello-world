import React from 'react'

const List = () => {
    return (
        <div style={{color: 'white', paddingTop: '95px', textAlign: 'center'}}>Coming soon</div>
    )
}

export default List