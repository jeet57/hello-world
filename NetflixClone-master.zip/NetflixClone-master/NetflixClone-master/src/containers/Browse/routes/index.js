import Home from './Home'
import Movies from './Movies'
import Tv from './Tv'
import LatestVideo from './LatestVideo'
import List from './List'

export {
    Home,
    Movies,
    Tv,
    LatestVideo, 
    List
}
